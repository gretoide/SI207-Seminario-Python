#include <stdio.h>
#include "B.h"

void show_B(const B_t elem)
{
  printf("(");show_A(elem.x);printf(",");show_A(elem.y);printf(")");
}

/*** EOF ***/
