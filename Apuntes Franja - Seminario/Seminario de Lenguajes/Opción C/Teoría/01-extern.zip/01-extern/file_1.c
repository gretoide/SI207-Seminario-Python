int extern_var = 20; 
