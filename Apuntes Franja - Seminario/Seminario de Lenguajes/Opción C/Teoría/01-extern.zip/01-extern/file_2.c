#include <stdio.h>

int main(){
  extern int extern_var;
  int automatic=5;
  printf("El valor de la variable extern_var es: %d\n", extern_var);
  printf("El valor de la variable automatic es: %d\n", automatic);
  return 0;
}
